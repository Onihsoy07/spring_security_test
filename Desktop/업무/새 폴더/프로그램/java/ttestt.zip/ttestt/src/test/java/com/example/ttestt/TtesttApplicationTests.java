package com.example.ttestt;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TtesttApplicationTests {

	@Test
	void contextLoads() {
	}

}
