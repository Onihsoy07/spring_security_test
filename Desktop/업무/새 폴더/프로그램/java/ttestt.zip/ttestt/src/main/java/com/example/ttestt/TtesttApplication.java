package com.example.ttestt;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TtesttApplication {

	public static void main(String[] args) {
		SpringApplication.run(TtesttApplication.class, args);
	}

}
